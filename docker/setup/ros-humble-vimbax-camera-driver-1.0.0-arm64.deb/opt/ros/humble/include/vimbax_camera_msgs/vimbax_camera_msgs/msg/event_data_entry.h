// generated from rosidl_generator_c/resource/idl.h.em
// with input from vimbax_camera_msgs:msg/EventDataEntry.idl
// generated code does not contain a copyright notice

#ifndef VIMBAX_CAMERA_MSGS__MSG__EVENT_DATA_ENTRY_H_
#define VIMBAX_CAMERA_MSGS__MSG__EVENT_DATA_ENTRY_H_

#include "vimbax_camera_msgs/msg/detail/event_data_entry__struct.h"
#include "vimbax_camera_msgs/msg/detail/event_data_entry__functions.h"
#include "vimbax_camera_msgs/msg/detail/event_data_entry__type_support.h"

#endif  // VIMBAX_CAMERA_MSGS__MSG__EVENT_DATA_ENTRY_H_
