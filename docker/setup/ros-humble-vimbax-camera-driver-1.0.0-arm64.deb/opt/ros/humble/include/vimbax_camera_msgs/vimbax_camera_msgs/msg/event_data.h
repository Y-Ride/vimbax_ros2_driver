// generated from rosidl_generator_c/resource/idl.h.em
// with input from vimbax_camera_msgs:msg/EventData.idl
// generated code does not contain a copyright notice

#ifndef VIMBAX_CAMERA_MSGS__MSG__EVENT_DATA_H_
#define VIMBAX_CAMERA_MSGS__MSG__EVENT_DATA_H_

#include "vimbax_camera_msgs/msg/detail/event_data__struct.h"
#include "vimbax_camera_msgs/msg/detail/event_data__functions.h"
#include "vimbax_camera_msgs/msg/detail/event_data__type_support.h"

#endif  // VIMBAX_CAMERA_MSGS__MSG__EVENT_DATA_H_
