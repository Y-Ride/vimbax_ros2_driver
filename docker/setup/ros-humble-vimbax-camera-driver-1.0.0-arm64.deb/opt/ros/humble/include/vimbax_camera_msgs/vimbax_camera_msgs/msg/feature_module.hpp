// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef VIMBAX_CAMERA_MSGS__MSG__FEATURE_MODULE_HPP_
#define VIMBAX_CAMERA_MSGS__MSG__FEATURE_MODULE_HPP_

#include "vimbax_camera_msgs/msg/detail/feature_module__struct.hpp"
#include "vimbax_camera_msgs/msg/detail/feature_module__builder.hpp"
#include "vimbax_camera_msgs/msg/detail/feature_module__traits.hpp"

#endif  // VIMBAX_CAMERA_MSGS__MSG__FEATURE_MODULE_HPP_
