// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef VIMBAX_CAMERA_MSGS__MSG__FEATURE_FLAGS_HPP_
#define VIMBAX_CAMERA_MSGS__MSG__FEATURE_FLAGS_HPP_

#include "vimbax_camera_msgs/msg/detail/feature_flags__struct.hpp"
#include "vimbax_camera_msgs/msg/detail/feature_flags__builder.hpp"
#include "vimbax_camera_msgs/msg/detail/feature_flags__traits.hpp"

#endif  // VIMBAX_CAMERA_MSGS__MSG__FEATURE_FLAGS_HPP_
