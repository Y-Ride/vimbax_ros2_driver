// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef VIMBAX_CAMERA_MSGS__SRV__CONNECTION_STATUS_HPP_
#define VIMBAX_CAMERA_MSGS__SRV__CONNECTION_STATUS_HPP_

#include "vimbax_camera_msgs/srv/detail/connection_status__struct.hpp"
#include "vimbax_camera_msgs/srv/detail/connection_status__builder.hpp"
#include "vimbax_camera_msgs/srv/detail/connection_status__traits.hpp"

#endif  // VIMBAX_CAMERA_MSGS__SRV__CONNECTION_STATUS_HPP_
