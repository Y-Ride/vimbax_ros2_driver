// generated from rosidl_generator_c/resource/idl.h.em
// with input from vimbax_camera_msgs:msg/FeatureFlags.idl
// generated code does not contain a copyright notice

#ifndef VIMBAX_CAMERA_MSGS__MSG__FEATURE_FLAGS_H_
#define VIMBAX_CAMERA_MSGS__MSG__FEATURE_FLAGS_H_

#include "vimbax_camera_msgs/msg/detail/feature_flags__struct.h"
#include "vimbax_camera_msgs/msg/detail/feature_flags__functions.h"
#include "vimbax_camera_msgs/msg/detail/feature_flags__type_support.h"

#endif  // VIMBAX_CAMERA_MSGS__MSG__FEATURE_FLAGS_H_
