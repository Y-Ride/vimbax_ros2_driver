// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef VIMBAX_CAMERA_MSGS__MSG__TRIGGER_INFO_HPP_
#define VIMBAX_CAMERA_MSGS__MSG__TRIGGER_INFO_HPP_

#include "vimbax_camera_msgs/msg/detail/trigger_info__struct.hpp"
#include "vimbax_camera_msgs/msg/detail/trigger_info__builder.hpp"
#include "vimbax_camera_msgs/msg/detail/trigger_info__traits.hpp"

#endif  // VIMBAX_CAMERA_MSGS__MSG__TRIGGER_INFO_HPP_
