// generated from rosidl_generator_c/resource/idl.h.em
// with input from vimbax_camera_msgs:msg/TriggerInfo.idl
// generated code does not contain a copyright notice

#ifndef VIMBAX_CAMERA_MSGS__MSG__TRIGGER_INFO_H_
#define VIMBAX_CAMERA_MSGS__MSG__TRIGGER_INFO_H_

#include "vimbax_camera_msgs/msg/detail/trigger_info__struct.h"
#include "vimbax_camera_msgs/msg/detail/trigger_info__functions.h"
#include "vimbax_camera_msgs/msg/detail/trigger_info__type_support.h"

#endif  // VIMBAX_CAMERA_MSGS__MSG__TRIGGER_INFO_H_
