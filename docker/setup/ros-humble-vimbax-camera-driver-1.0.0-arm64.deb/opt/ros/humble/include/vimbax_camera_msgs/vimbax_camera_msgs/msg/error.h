// generated from rosidl_generator_c/resource/idl.h.em
// with input from vimbax_camera_msgs:msg/Error.idl
// generated code does not contain a copyright notice

#ifndef VIMBAX_CAMERA_MSGS__MSG__ERROR_H_
#define VIMBAX_CAMERA_MSGS__MSG__ERROR_H_

#include "vimbax_camera_msgs/msg/detail/error__struct.h"
#include "vimbax_camera_msgs/msg/detail/error__functions.h"
#include "vimbax_camera_msgs/msg/detail/error__type_support.h"

#endif  // VIMBAX_CAMERA_MSGS__MSG__ERROR_H_
