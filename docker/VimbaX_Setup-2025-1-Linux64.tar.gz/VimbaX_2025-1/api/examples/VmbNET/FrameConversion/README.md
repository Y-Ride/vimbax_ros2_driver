
Before building this example, `user.build.props.TEMPLATE` must be renamed to `user.build.props`
and the text `place-runtime-identifier-here` in `user.build.props`
must be replaced with either `win-x64`, `linux-arm64` or `linux-x64`, depending on the desired platform.

Ubuntu/Debian users: Please install the necessary OpenCV dependencies with `apt install libopencv-dev`
